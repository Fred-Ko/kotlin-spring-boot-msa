---
description: 빌드
---

빌드 순서는 다음과 같다.

independent 모듈
domains/common/domain 모듈
domains/common/infrastructure 모듈
domains/common/application 모듈
domains/common/presentation 모듈

domains/user/domain 모듈
domains/user/infrastructure 모듈
domains/user/application 모듈
domains/user/presentation 모듈

위 순서대로 빌드를 진행하라.
package com.restaurant.user.application.dto.query

data class GetUserProfileByIdQuery(
    val userId: String,
)

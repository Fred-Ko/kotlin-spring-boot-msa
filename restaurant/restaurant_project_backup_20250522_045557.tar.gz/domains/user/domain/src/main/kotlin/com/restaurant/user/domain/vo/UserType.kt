package com.restaurant.user.domain.vo

/**
 * Represents the type of user.
 */
enum class UserType {
    CUSTOMER,
    ADMIN,
}

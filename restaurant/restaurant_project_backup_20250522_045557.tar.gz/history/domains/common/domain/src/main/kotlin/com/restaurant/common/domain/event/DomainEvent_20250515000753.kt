package com.restaurant.common.domain.event

import java.time.Instant
import java.util.UUID

interface DomainEvent {
 val eventId: UUID
 val eventType: String
 val occurredAt: Instant
 val aggregateId: String
 val aggregateType: String
}

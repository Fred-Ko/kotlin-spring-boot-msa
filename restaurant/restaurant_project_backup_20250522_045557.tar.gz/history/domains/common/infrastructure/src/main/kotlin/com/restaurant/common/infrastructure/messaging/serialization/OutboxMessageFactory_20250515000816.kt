package com.restaurant.common.infrastructure.messaging.serialization

import com.restaurant.common.domain.event.DomainEvent
import com.restaurant.outbox.application.port.model.OutboxMessage
import com.restaurant.outbox.application.port.model.OutboxMessageStatus

class OutboxMessageFactory {
 fun createOutboxMessage(event: DomainEvent, topic: String): OutboxMessage {
 val payload = serializeToAvro(event)
 val topic = topic
 val headers = mapOf(
 "eventType" to event.eventType,
 "aggregateType" to event.aggregateType,
 "aggregateId" to event.aggregateId,
 "eventId" to event.eventId.toString()
 )
 val aggregateType = event.aggregateType
 val aggregateId = event.aggregateId
 val eventType = event.eventType
 }
 }

 private fun serializeToAvro(event: DomainEvent): ByteArray {
 // Avro 직렬화 로직 (별도 구현 필요)
 return byteArrayOf()
 }
}
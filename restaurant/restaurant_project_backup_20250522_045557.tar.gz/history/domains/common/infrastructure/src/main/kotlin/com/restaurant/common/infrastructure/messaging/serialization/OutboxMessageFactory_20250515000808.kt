package com.restaurant.common.infrastructure.messaging.serialization

import com.restaurant.common.domain.event.DomainEvent
import com.restaurant.outbox.application.port.model.OutboxMessage

class OutboxMessageFactory {
 fun createOutboxMessage(event: DomainEvent, topic: String): OutboxMessage {
 val payload = serializeToAvro(event) 
 val headers = mutableMapOf<String, String>()
 headers["eventType"] = event.eventType
 headers["aggregateType"] = event.aggregateType
 headers["aggregateId"] = event.aggregateId
 headers["eventId"] = event.eventId.toString()

 return OutboxMessage(
 payload = payload,
 topic = topic,
 headers = headers
 )
 }

 private fun serializeToAvro(event: DomainEvent): ByteArray {
 // Avro 직렬화 로직 (별도 구현 필요)
 return byteArrayOf()
 }
}
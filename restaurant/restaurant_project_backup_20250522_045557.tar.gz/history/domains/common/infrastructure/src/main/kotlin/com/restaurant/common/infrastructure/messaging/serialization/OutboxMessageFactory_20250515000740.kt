package com.restaurant.common.infrastructure.messaging.serialization

import com.restaurant.common.domain.event.DomainEvent
import com.restaurant.outbox.application.port.model.OutboxMessage

class OutboxMessageFactory {
 fun createOutboxMessage(event: DomainEvent, topic: String): OutboxMessage {
 val payload = serializeToAvro(event) 
 return OutboxMessage(
 payload = payload,
 topic = topic,
 headers = mapOf(
 "aggregateType" to event.aggregateType,
 "aggregateId" to event.aggregateId,
 "eventId" to event.eventId.toString()
 )
 )
 }

 private fun serializeToAvro(event: DomainEvent): ByteArray {
 // Avro 직렬화 로직 (별도 구현 필요)
 return byteArrayOf()
 }
}

echo -e "\n==============================================================" >>$OUTPUT_FILE
echo -e "\n# Project Structure\n" >>$OUTPUT_FILE
tree domains independent apps gradle \
  -I 'build|bin|test' \
  -P '*.kt|*.kts|*.gradle|*.avsc' \
  >>$OUTPUT_FILE
echo -e "==============================================================\n\n" >>$OUTPUT_FILE

# Collect and append Kotlin/Gradle files with enhanced separators
find domains/user domains/common settings.gradle.kts build.gradle.kts apps independent gradle/libs.versions.toml \
  -type d \( -name build -o -name bin -o -name test \) -prune -o \
  -type f \( -name "*.kt" -o -name "*.kts" -o -name "*.gradle" -o -name "*toml" -o -name "settings.gradle.kts" -o -name "build.gradle.kts" -o -name "*.avsc" \) -print | \
  sort -u | \
  while IFS= read -r file; do
    {
      echo -e "\n\n===================================================================="
      echo -e " File: $file"
      # Use realpath if available, fallback to readlink -f for compatibility
      if command -v realpath >/dev/null 2>&1; then
        echo -e " Path: $(realpath --relative-to=. "$file" 2>/dev/null || echo "$file")"
      else
        echo -e " Path: $(readlink -f "$file" 2>/dev/null || echo "$file")"
      fi
      # Use portable date format
      echo -e " Timestamp: $(date -u '+%Y-%m-%d %H:%M:%S')"
      echo -e "===================================================================="
      cat "$file"
      echo -e "\n====================================================================n"
    } >>"$OUTPUT_FILE"
  done
